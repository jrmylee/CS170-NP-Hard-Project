# README file for Course Staff to Read
How to run all submissions:
python3 index.py

This will call "final_submission" function in index.py which will parse the inputs, and send them to the processor in process.py.

The inputs directory is in the project folder.